#include "dlstorm.h"
#include "c_net.h"
#include "c_margs.h"
using namespace DLCODESTORM;
int main(int argc, char * argv[]) {
    C_Muh_Args margs(argc,argv,true);
    for (int i=0; i<argc; i++) cout << margs.get_arg(i) << " " << i << endl;

    cout << "START +++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;
    cout << "OPERATING SYSTEM:" << dlcs_get_os_version() << endl;
    cout << "HOSTNAME:" << dlcs_get_hostname() << endl;
    cout << "IPADDRESS:" << dlcs_get_ipaddress() << endl;

    cout << "GET +++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;


    cout << dlcs_dns_lookup("3dnetlabs.info") << endl;

   //  cout << dlcs_get_webpage(margs.get_arg(1)) << endl ;

    cout << "+++++++++++++++++++++++++++++++++++++++++++++++++++++ END" << endl;

    return 0;
}
